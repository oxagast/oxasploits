PHONE="08:AE:D6:6F:DD:F8"
echo "Pairing to ${PHONE}"
CONTR=`echo "power on\n\nshow\n\ndiscoverable on\n\npair ${PHONE}\n\ntrust ${PHONE}\n\nconnect ${PHONE}\n\n" | bluetoothctl | grep Controller | cut -d ' ' -f 2`
echo "Paired ${PHONE} to ${CONTR}"
echo "Prepped to send file to ${PHONE}..."
python3 rougetooth_force_file.py "${CONTR}" "${PHONE}"
