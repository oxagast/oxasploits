Need to run `sudo systemctl stop bluetooth`, then run: `bluetoothd -P input`.

Now pair the device, and: `sudo ./force_file.sh`.

It should try to push the file, then accept the file itself by bringing up a HID controller on the computer side, and emulating the keypresses needed
from a hardware keyboard to accept the transfer.  This is a benign proof of concept, but uploading a meterpreter shell and running it this way is possible.

Tested on: linux kernel 6.1.12, bluetoothd 5.66

python libraries: python-xlib 0.27, dbus-python 1.2.16

 
