/* The system doesn't have <unistd.h>.  */
